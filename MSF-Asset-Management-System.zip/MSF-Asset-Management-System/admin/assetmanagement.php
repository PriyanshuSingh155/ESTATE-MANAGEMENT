<?php
session_start();
include '../config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/assetmanagement.css">
    <title>MSF - Admin</title>
</head>

<body>
    <!-- add asset panel -->

    <div id="assetdetailpanel">
        <form action="" method="POST" class="assetdetailpanelform">
            <div class="head">
                <h4>ASSET MANAGEMENT</h4>
                <i class="fa-solid fa-circle-xmark" onclick="addassetclose()"></i>
            </div>
            <div class="middle">
                <div class="assetinfo">
                    <h4>ADD Asset or Quarters</h4>
        
                    <select name="estate" class="selectinput">
						<option value selected >Estate</option>
                        <option value="Park Estate">Park Estate</option>
                        <option value="Palta Park Estate">Palta Park Estate</option>
						<option value="NorthLand Estate">NorthLand Estate</option>
						<option value="EastLAnd Estate">EastLAnd Estate</option>
                        <option value="OWL Estate">OWL Estate</option>
                    </select>

                    <select name="type" class="selectinput">
						<option value selected >Type</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
						<option value="7">7</option>
                        <option value="8">8</option>
                    </select>

                    <input type="text" name="qtrno" placeholder="Enter Qtr No." required>
                    <input type="text" name="flrno" placeholder="Floor No." required>
                    <input type="text" name="totr" placeholder="Total Rooms" required>
                    <input type="text" name="avlr" placeholder="Available Rooms" required>
                </div>

                
            </div>
            <div class="footer">
                <button class="btn btn-success" name="assetdetailsubmit">Add</button>
            </div>
        </form
    

        
        <?php
        // <!-- ====  add asset book php ====-->

            if (isset($_POST['assetdetailsubmit'])) {
                $Estate = $_POST['estate'];
                $Type = $_POST['type'];
                $QtrNo = $_POST['qtrno'];
                $Floor = $_POST['flrno'];
                $TotRoom = $_POST['totr'];
                $AvlRoom = $_POST['avlr'];

                if($Estate == "Estate" || $Type == "Type"){
                    echo "<script>swal({
                        title: 'Select proper details',
                        icon: 'error',
                    });
                    </script>";
                }
                else{
                    
                    $sql = "INSERT INTO asset_management(Estate,Type,QtrNo,Floor,noofroom,avlroom) VALUES ('$Estate','$Type','$QtrNo','$Floor','$TotRoom','$AvlRoom')";
                    $result = mysqli_query($conn, $sql);

                    if ($result) {
                        echo "<script>swal({
                            title: 'Room Added',
                            icon: 'success',
                        });
                    </script>";
                    } else {
                        echo "<script>swal({
                                title: 'Something went wrong',
                                icon: 'error',
                            });
                    </script>";
                    }

                }   
            }
        ?>
        <!-- room availablity end -->
    </div>

    
    <!-- ================================================= -->
    <div class="searchsection">
        <input type="text" name="search_bar" id="search_bar" placeholder="search Estate name..." onkeyup="searchFun()">
        <button class="addasset" id="addasset" onclick="addassetopen()"><i class="fa-solid fa-bookmark"></i> Add Asset</button>
        <form action="./exportdata.php" method="post">
            <button class="exportexcel" id="exportexcel" name="exportexcel" type="submit"><i class="fa-solid fa-file-arrow-down"></i></button>
        </form>
    </div>

    <div class="assetmanagementtable" class="table-responsive-xl">
        <?php
            $roombooktablesql = "SELECT * FROM asset_management ";
            $roombookresult = mysqli_query($conn, $roombooktablesql);
            $nums = mysqli_num_rows($roombookresult);
        ?>
        <table class="table table-bordered" id="table-data">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Estate</th>
                    <th scope="col">Type</th>
                    <th scope="col">QtrNo</th>
                    <th scope="col">Floor</th>
                    <th scope="col">Total Rooms</th>
                    <th scope="col">Available Rooms</th>
                    <th scope="col" class="action">Action</th>
                </tr>
            </thead>

            <tbody>
            <?php
            while ($res = mysqli_fetch_array($roombookresult)) {
            ?>
                <tr>
                    <td><?php echo $res['id'] ?></td>
                    <td><?php echo $res['Estate'] ?></td>
                    <td><?php echo $res['Type'] ?></td>
                    <td><?php echo $res['Qtrno'] ?></td>
                    <td><?php echo $res['Floor'] ?></td>
                    <td><?php echo $res['noofroom'] ?></td>
                    <td><?php echo $res['avlroom'] ?></td>
                    <td class="action">
                    <a href="assetmanagementedit.php?id=<?php echo $res['id'] ?>"><button class="btn btn-primary">Edit</button></a>
                    <a href="assetmanagementdelete.php?id=<?php echo $res['id'] ?>"><button class='btn btn-danger'>Delete</button></a>
                
                                               
                    </td>
                </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</body>
<script src="./javascript/assetmanagement.js"></script>



</html>
