<?php

include '../config.php';

$id = $_GET['id'];

$deletesql = "DELETE FROM asset_management WHERE id = $id";

$result = mysqli_query($conn, $deletesql);

header("Location:assetmanagement.php");

?>