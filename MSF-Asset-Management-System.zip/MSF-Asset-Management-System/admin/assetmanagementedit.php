<?php

include '../config.php';

// fetch room data
$id = $_GET['id'];

$sql ="Select * from asset_management where id = '$id'";
$re = mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($re))
{
    $Estate = $row['Estate'];
    $Type = $row['Type'];
    $Qtrno = $row['Qtrno'];
    $Floor = $row['Floor'];
    $NoOfRoom = $row['noofroom'];
    $AvlRoom = $row['avlroom'];
}

if (isset($_POST['assetdetailedit'])) {
    $EditEstate = $_POST['estate'];
    $EditType = $_POST['type'];
    $EditQtrNo = $_POST['qtrno'];
    $EditFloor = $_POST['flrno'];
    $EditTotRoom = $_POST['totr'];
    $EditAvlRoom = $_POST['avlr'];    

    $sql = "UPDATE asset_management SET Estate = '$EditEstate',Type= '$EditType',Qtrno='$EditQtrNo',Floor='$EditFloor',noofroom='$EditTotRoom',avlroom='$EditAvlRoom' WHERE id = '$id'";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location:assetmanagement.php");
    }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/assetmanagement.css">
    <style>
        #editpanel{
            position : fixed;
            z-index: 1000;
            height: 100%;
            width: 100%;
            display: flex;
            justify-content: center;
            /* align-items: center; */
            background-color: #00000079;
        }
        #editpanel .assetdetailpanelform{
            height: 620px;
            width: 1170px;
            background-color: #ccdff4;
            border-radius: 10px;  
            /* temp */
            position: relative;
            top: 20px;
            animation: assetinfoform .3s ease;
        }

    </style>
    <title>Document</title>
</head>
<body>
    <div id="editpanel">
        <form method="POST" class="assetdetailpanelform">
            <div class="head">
                <h3>EDIT RESERVATION</h3>
                <a href="./assetmanagement.php"><i class="fa-solid fa-circle-xmark" onclick="adduserclose()"></i></a>
            </div>
            <div class="middle">
                <div class="assetinfo">
                    <h4>Edit Asset or Quarters</h4>
                    
                    <select name="estate" class="selectinput">
                    

                        <option value="<?php echo $Estate ?>" selected ><?php echo $Estate ?></option>
                        <option value="Park Estate">Park Estate</option>
                        <option value="Palta Park Estate">Palta Park Estate</option>
                        <option value="NorthLand Estate">NorthLand Estate</option>
                        <option value="EastLAnd Estate">EastLAnd Estate</option>
                        <option value="OWL Estate">OWL Estate</option>
                    </select>

                    <select name="type" class="selectinput">
                        <option value="<?php echo $Type ?>" selected ><?php echo $Type ?></option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                    </select>

                    <input type="text" name="qtrno" placeholder="Enter Qtr No." value="<?php echo $Qtrno ?>">
                    <input type="text" name="flrno" placeholder="Floor No." value="<?php echo $Floor ?>">
                    <input type="text" name="totr" placeholder="Total Rooms" value="<?php echo $NoOfRoom ?>">
                    <input type="text" name="avlr" placeholder="Available Rooms" value="<?php echo $AvlRoom ?>">
                </div>
            </div>
            <div class="footer">
                <button class="btn btn-success" name="assetdetailedit">Edit</button>
            </div>
        </form>
    </div>
</body>
</html>