<?php
session_start();
include '../config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/permanentbooking.css">
    <title>BlueBird - Admin</title>
</head>

<body>
    <!--permanentbookingpanel -->

    <div id="permanentbookingpanel">
        <form action="" method="POST" class="permanentbookingpanelform">
            <div class="head">
                <h3>ALLOTTMENT OF QUARTERS</h3>
                <i class="fa-solid fa-circle-xmark" onclick="permanentbookingclose()"></i>
            </div>
            <div class="middle">
                <div class="permanentbookinginfo">
                    <input type="text" name="Quarters_No" placeholder="Quarters No. applied for" required>
                    <input type="text" name="Name" placeholder="Name" required>
                    <input type="text" name="Designation" placeholder=" Designation" required>
                    <input type="text" name="Section" placeholder="Section" required>
                    <input type="text" name="Establishment" placeholder="Estt." required>
                    <input type="text" name="TNo" placeholder="T. No/Per. No" required>
                    <input type="text" name="Basic" placeholder="Present Basic Pay & Pay Level in 7th" required>
                    <select name="Categorized_By" class="selectinput">
                    <option value selected>Whether SC/ST</option>
                    <option value="SC">Yes</option>
                    <option value="ST">No</option>
                    </select>

                </div>

                <div class="line"></div>

                <div class="reservationinfo">
                    <label for="date">Date of Appointment:</label><input type="date" name="Appointment" placeholder="Date of Appointment" required>
                    <label for="date">Date of Birth:</label><input type="date" name="BirthDate" placeholder="Date of Birth" required>
                    <input type="text" name="Present_Qtrs" placeholder="Present Qtrs. if any and since when" required>
                    <input type="text" name="Choice_Qtrs" placeholder="Preference for Choice of Quarters" required>
                    <input type="text" name="Earlier_changeover" placeholder="Whether any changeover has been made in earlier." required>
                    <input type="text" name="Surrendered_Qtrs" placeholder="Whether any Qtrs. surrendered in the past. " required>
                    <input type="text" name="Service" placeholder="Whether spouse is Govt. Service Holder " required>
                    <input type="text" name="Contact" placeholder="Contact No.(Mobile.No.)" required>
                </div>
            </div>
            <div class="footer">
                <button class="btn btn-success" name="permanentbookingsubmit">Submit</button>
            </div>
        </form>

        <!-- ==== permanentbooking php ====-->
        <?php       
            if (isset($_POST['permanentbookingsubmit'])) {
                $Quarters = $_POST['Quarters_No'];
                $Name = $_POST['Name'];
                $Designation = $_POST['Designation'];
                $section = $_POST['Section'];
                $Estt = $_POST['Establishment'];
                $TNo = $_POST['TNo'];
                $PayLevel = $_POST['Basic'];
                $category = $_POST['Categorized_By'];
                $Appointment = $_POST['Appointment'];
                $date_of_birth = $_POST['BirthDate'];
                $present_Qtrs = $_POST['Present_Qtrs'];
                $Choice_Qtrs = $_POST['Choice_Qtrs'];
                $Earlier_changeover = $_POST['Earlier_changeover'];
                $Surrendered_Qtrs = $_POST['Surrendered_Qtrs'];
                $Service = $_POST['Service'];
                $Contact = $_POST['Contact'];

                $sql = "INSERT INTO permanent(Quarters_No,Name,Designation,Section,Establishment,TNo,Basic,Categorized_By,Appointment,BirthDate,Present_Qtrs,Choice_Qtrs,Earlier_changeover,Surrendered_Qtrs,Service,Contact) VALUES ('$Quarters','$Name','$Designation','$section','$Estt','$TNo','$PayLevel','$category','$Appointment','$date_of_birth ','$present_Qtrs','$Choice_Qtrs','$Earlier_changeover','$Surrendered_Qtrs','$Service','$Contact')";
                $result = mysqli_query($conn, $sql);

            }
        ?>

        <!-- permanentbooking end-->
    </div>

    
    <!-- ================================================= -->
    <div class="searchsection">
        <input type="text" name="search_bar" id="search_bar" placeholder="search  TNo..." onkeyup="searchFun()">
        <button class="permanentbooking" id="permanentbooking" onclick="permanentbookingopen()"><i class="fa-solid fa-bookmark"></i>Form for Allotment Of Quarters</button>
        <form action="./permanentbookingexportdata.php" method="post">
            <button class="exportexcel" id="exportexcel" name="exportexcel" type="submit"><i class="fa-solid fa-file-arrow-down"></i></button>
        </form>
    </div>

    <div class="permanentbookingtable" class="table-responsive-xl">
        <?php
            $roombooktablesql = "SELECT * FROM permanent";
            $roombookresult = mysqli_query($conn, $roombooktablesql);
            $nums = mysqli_num_rows($roombookresult);
        ?>
        <table class="table table-bordered" id="table-data">
            <thead>
                <tr>

                <th scope="col">TNo</th>

            <th scope="col">Quarters_No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Designation</th>
                    <th scope="col">Section</th>                   
                    <th scope="col">Establishment</th>
                    <th scope="col">Basic</th>
                    <th scope="col">Categorized_By</th>
                    <th scope="col">Appointment</th>
                    <th scope="col">BirthDate</th>
                    <th scope="col">Present_Qtrs</th>
                    <th scope="col">Choice_Qtrs</th>
                    <th scope="col">Earlier_changeover</th>
                    <th scope="col">Surrendered_Qtrs</th>
                    <th scope="col">Service</th>
                    <th scope="col">Contact</th>
                    <th scope="col" class="action">Action</th>
                </tr>
            </thead>

            <tbody>
            <?php
            while ($res = mysqli_fetch_array($roombookresult)) {
            ?>
                <tr>

                <td><?php echo $res['TNo'] ?></td>

                <td><?php echo $res['Quarters_No'] ?></td>
                    <td><?php echo $res['Name'] ?></td>
                    <td><?php echo $res['Designation'] ?></td>
                    <td><?php echo $res['Section'] ?></td>

                    <td><?php echo $res['Establishment'] ?></td>
                
                    <td><?php echo $res['Basic'] ?></td>
                    <td><?php echo $res['Categorized_By'] ?></td>
                    <td><?php echo $res['Appointment'] ?></td>
                    <td><?php echo $res['BirthDate'] ?></td>
                    <td><?php echo $res['Present_Qtrs'] ?></td>
                    <td><?php echo $res['Choice_Qtrs'] ?></td>
                    <td><?php echo $res['Earlier_changeover'] ?></td>
                    <td><?php echo $res['Surrendered_Qtrs'] ?></td>
                    <td><?php echo $res['Service'] ?></td>
                    <td><?php echo $res['Contact'] ?></td>
                    <td class="action">
                        <a href="permanentbookingedit.php?TNo=<?php echo $res['TNo'] ?>"><button class="btn btn-primary">Edit</button></a>
                        <a href="permanentbookingdelete.php?TNo=<?php echo $res['TNo'] ?>"><button class='btn btn-danger'>Delete</button></a>
                    </td>
                </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</body>
<script src="./javascript/permanentbooking.js"></script>



</html>
