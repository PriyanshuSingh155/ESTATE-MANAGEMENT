<?php

include '../config.php';

$TNo = $_GET['TNo'];

$deletesql = "DELETE FROM permanent WHERE TNo = '$TNo' ";

$result = mysqli_query($conn, $deletesql);

header("Location:permanentbooking.php");

?>