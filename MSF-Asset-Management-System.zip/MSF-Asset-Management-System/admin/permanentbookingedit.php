<?php

include '../config.php';

// fetch room data
$TNo = $_GET['TNo'];

$sql ="Select * from permanent where TNo='$TNo'";
$re = mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($re))
{
                $Quarters = $row['Quarters_No'];
                $Name = $row['Name'];
                $Designation =$row['Designation'];
                $section = $row['Section'];
                $Estt = $row['Establishment'];
                $TNo = $row['TNo'];
                $PayLevel = $row['Basic'];
                $category = $row['Categorized_By'];
                $Appointment = $row['Appointment'];
                $date_of_birth = $row['BirthDate'];
                $present_Qtrs = $row['Present_Qtrs'];
                $Choice_Qtrs = $row['Choice_Qtrs'];
                $Earlier_changeover = $row['Earlier_changeover'];
                $Surrendered_Qtrs = $row['Surrendered_Qtrs'];
                $Service = $row['Service'];
                $Contact = $row['Contact'];
}

if (isset($_POST['permanentbookingedit'])) {
    $EditQuarters = $_POST['Quarters_No'];
    $EditName = $_POST['Name'];
    $EditDesignation = $_POST['Designation'];
    $Editsection = $_POST['Section'];
    $EditEstt = $_POST['Establishment'];
    $EditTNo = $_POST['TNo'];
    $EditPayLevel = $_POST['Basic'];
    $Editcategory = $_POST['Categorized_By'];
    $EditAppointment = $_POST['Appointment'];
    $Editdate_of_birth = $_POST['BirthDate'];
    $Editpresent_Qtrs = $_POST['Present_Qtrs'];
    $EditChoice_Qtrs = $_POST['Choice_Qtrs'];
    $EditEarlier_changeover = $_POST['Earlier_changeover'];
    $EditSurrendered_Qtrs = $_POST['Surrendered_Qtrs'];
    $EditService = $_POST['Service'];
    $EditContact = $_POST['Contact'];


    $sql = "UPDATE permanent SET Quarters_No='$EditQuarters',Name = '$EditName',Designation = '$EditDesignation',Section='$Editsection',Establishment='$EditEstt',Basic='$EditPayLevel',Categorized_By='$Editcategory',Appointment='$EditAppointment',BirthDate='$Editdate_of_birth',Present_Qtrs='$Editpresent_Qtrs',Choice_Qtrs = '$EditChoice_Qtrs',Earlier_changeover='$EditEarlier_changeover', Surrendered_Qtrs='$EditSurrendered_Qtrs',Service='$EditService',Contact='$EditContact' WHERE TNo = '$EditTNo'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("Location:permanentbooking.php");
}
}
?>

    

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/permanentbooking.css">
    <style>
        #editpanel{
            position : fixed;
            z-index: 1000;
            height: 100%;
            width: 100%;
            display: flex;
            justify-content: center;
            /* align-items: center; */
            background-color: #00000079;
        }
        #editpanel .permanentbookingpanelform{
            height: 620px;
            width: 1170px;
            background-color: #ccdff4;
            border-radius: 10px;  
            /* temp */
            position: relative;
            top: 20px;
            animation: permanentbookinginfoform .3s ease;
        }

    </style>
    <title>Permanent Booking</title>
</head>
<body>
    <div id="editpanel">
        <form method="POST" class="permanentbookingpanelform">
            <div class="head">
                <h3>EDIT BOOKING DETAILS</h3>
                <a href="./permanentbooking.php"><i class="fa-solid fa-circle-xmark"onclick="permanentbookingclose()"></i></a>
            </div>
            <div class="middle">
                <div class="permanentbookinginfo">
                    <input type="text" name="Quarters_No" value="<?php echo $Quarters ?>">
                    <input type="text" name="Name" value="<?php echo $Name ?>">
                    <input type="text" name="Designation" value="<?php echo  $Designation  ?>">
                    <input type="text" name="Section" value="<?php echo $section ?>">
                    <input type="text" name="Establishment" value="<?php echo $Estt ?>">
                    <input type="text" name="TNo" value="<?php echo $TNo ?>">
                    <input type="text" name="Basic" value="<?php echo $PayLevel ?>">
                    <input type="text" name="Categorized_By" value="<?php echo $category ?>">
                    </div>

                    <div class="line"></div>

                    <div class="reservationinfo">
                    <input type="date" name="Appointment" value="<?php echo $Appointment ?>">
                    <input type="date" name="BirthDate" value="<?php echo $date_of_birth ?>">
                    <input type="text" name="Present_Qtrs" value="<?php echo $present_Qtrs ?>">
                    <input type="text" name="Choice_Qtrs" value="<?php echo  $Choice_Qtrs ?>">
                    <input type="text" name="Earlier_changeover" value="<?php echo $Earlier_changeover?>">
                    <input type="text" name="Surrendered_Qtrs" value="<?php echo $Surrendered_Qtrs ?>">
                    <input type="text" name="Service" value="<?php echo  $Service ?>">
                    <input type="text" name="Contact" value="<?php echo $Contact ?>">
                </div>
            </div>
            <div class="footer">
                <button class="btn btn-success" name="permanentbookingedit">Edit</button>
            </div>
        </form>
    </div>
</body>
</html>