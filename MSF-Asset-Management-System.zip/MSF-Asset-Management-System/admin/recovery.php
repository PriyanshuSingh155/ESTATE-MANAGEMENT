<?php
session_start();
include '../config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/recovery.css">
    <title>MSF - Admin</title>
</head>

<body>
    <!-- Recovery -->

    <div id="recoverydetailpanel">
        <form action="" method="POST" class="recoverydetailpanelform">
            <div class="head">
                <h3>Recovery</h3>
                <i class="fa-solid fa-circle-xmark" onclick="addrecoveryclose()"></i>
            </div>
            <div class="middle">
                <div class="recoveryinfo">
                    <h4>Rent Calculation</h4>
                    <input type="text" name="TNo" placeholder="Ticket No." required>
                    <input type="number" name="Lfee" placeholder="License Fee" required>
                    <input type="number" name="Cfee" placeholder="Conservancy Fee" required>
                    <input type="number" name="Wfee" placeholder="Water Fee" required>
                    <input type="number" name="Efee" placeholder="Electricity Fee" required>
                    <input type="number" name="Mfee" placeholder="Miscellaneous Fee" required>
                    <!-- <input type="text" name="Total" value="" readonly> -->

                </div>
            </div>
            <div class="footer">
                <button class="btn btn-success" name="recoverydetailsubmit">Submit</button>
            </div>
        </form>











        <!-- ==== room book php ====-->
        <?php
        if (isset($_POST['recoverydetailsubmit'])) {
            $TNo = $_POST['TNo'];
            $Lfee = $_POST['Lfee'];
            $Cfee = $_POST['Cfee'];
            $Wfee = $_POST['Wfee'];
            $Efee = $_POST['Efee'];
            $Mfee = $_POST['Mfee'];
            // $total = $_POST['Total'];


            // Calculate the total
            $total = $Lfee + $Cfee + $Wfee + $Efee + $Mfee;

            $Arr = $total;
            $sql = "INSERT INTO rentcalc (TNo,Lfee,Cfee,Wfee,Efee,Mfee,Arr,Total) VALUES ('$TNo',$Lfee,$Cfee,$Wfee,$Efee,$Mfee,$Arr,$total)";
            $result = mysqli_query($conn, $sql);
            $sql1 = "INSERT INTO dues (TNO,Arr) VALUES('$TNo',$Arr)";
            $result1 = mysqli_query($conn, $sql1);
        }
        ?>
    </div>


    <!-- ================================================= -->
    <div class="searchsection">
        <input type="text" name="search_bar" id="search_bar" placeholder="search TNo..." onkeyup="searchFun()">
        <button class="addrecovery" id="addrecovery" onclick="addrecoveryopen()"><i class="fa-solid fa-bookmark"></i> Add</button>
        <form action="./recoveryexport.php" method="post">
            <button class="exportexcel" id="exportexcel" name="exportexcel" type="submit"><i class="fa-solid fa-file-arrow-down"></i></button>
        </form>
    </div>

    <div class="recoverytable" class="table-responsive-xl">
        <?php
        $rentcaltablesql = "SELECT * FROM rentcalc";
        $rentcalresult = mysqli_query($conn, $rentcaltablesql);
        $nums = mysqli_num_rows($rentcalresult);
        ?>
        <table class="table table-bordered" id="table-data">
            <thead>
                <tr>
                    <th scope="col">Ticket No.</th>
                    <th scope="col">License fee</th>
                    <th scope="col">Conservancy fee</th>
                    <th scope="col">Water fee</th>
                    <th scope="col">Electricity fee</th>
                    <th scope="col">Misecellneous fee</th>
                    <th scope="col">Total</th>
                    <th scope="col">Due's</th>
                    <th scope="col" class="action">Action</th>
                    <!-- <th>Delete</th> -->
                </tr>
            </thead>

            <tbody>
                <?php
                while ($res = mysqli_fetch_array($rentcalresult)) {
                ?>
                    <tr>
                        <td><?php echo $res['TNo'] ?></td>
                        <td><?php echo $res['Lfee'] ?></td>
                        <td><?php echo $res['Cfee'] ?></td>
                        <td><?php echo $res['Wfee'] ?></td>
                        <td><?php echo $res['Efee'] ?></td>
                        <td><?php echo $res['Mfee'] ?></td>
                        <td><?php echo $res['Total'] ?></td>
                        <td><?php echo $res['Arr'] ?></td>
                        <td class="action">
                            <?php
                            // if($res['stat'] == "Confirm")
                            // {
                            //     echo " ";
                            // }
                            // else
                            // {
                            //     echo "<a href='roomconfirm.php?id=". $res['id'] ."'><button class='btn btn-success'>Confirm</button></a>";
                            // }
                            ?>
                            <a href="recoverypaid.php?TNo=<?php echo $res['TNo'] ?>"><button class="btn btn-primary">Paid</button></a>
                            <a href="recoveryunpaid.php?TNo=<?php echo $res['TNo'] ?>"><button class="btn btn-primary">Add Next Month</button></a>
                            <a href="recoverydelete.php?TNo=<?php echo $res['TNo'] ?>"><button class='btn btn-danger'>Delete</button></a>
                            <a href="recoveryedit.php?TNo=<?php echo $res['TNo'] ?>"><button class="btn btn-primary">Edit</button></a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
<script src="./javascript/recovery.js"></script>



</html>