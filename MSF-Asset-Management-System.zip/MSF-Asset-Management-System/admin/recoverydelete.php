<?php

include '../config.php';

$TNo = $_GET['TNo'];

$deletesql = "DELETE FROM rentcalc WHERE TNo = '$TNo'";

$result = mysqli_query($conn, $deletesql);
$deletesql1 = "DELETE FROM dues WHERE TNo = '$TNo'";
$result1 = mysqli_query($conn, $deletesql1);
header("Location:recovery.php");
?>
<?php
?>