<?php

include '../config.php';

$TNo= $_GET['TNo'];

$deletesql = "DELETE FROM newregistration WHERE TNo = '$TNo'";

$result = mysqli_query($conn, $deletesql);

header("Location:booking.php");

?>