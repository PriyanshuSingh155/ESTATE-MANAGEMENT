<?php

include '../config.php';

// fetch room data
$TNo = $_GET['TNo'];

$sql = "Select * from newregistration where TNo = '$TNo'";
$re = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_array($re)) {
    $Name = $row['Name'];
    $Designation = $row['Designation'];
    $Section = $row['Section'];
    $Establishment = $row['Establishment'];
    $TNo = $row['TNo'];
    $Location = $row['Location'];
    $Bookingdate = $row['Bookingdate'];
    $Bookingpurpose = $row['BookingPurpose'];
    $Contactno = $row['Contactno'];
    $Authorizedby = $row['Authorizedby'];
    $Otherdetails = $row['OtherDetails'];
    $Advpaymentdetails = $row['AdvPaymentdetails'];
}

if (isset($_POST['tempbookingedit'])) {
    $EditTNo = $_POST['TNo'];
    $EditName = $_POST['Name'];
    $EditDesignation = $_POST['Designation'];
    $EditSection = $_POST['Section'];
    $EditEstablishment = $_POST['Establishment'];
    $EditLocation = $_POST['Location'];
    $EditBookingdate = $_POST['Bookingdate'];
    $EditBookingpurpose = $_POST['BookingPurpose'];
    $EditContactno = $_POST['Contactno'];
    $EditAuthorizedby = $_POST['Authorizedby'];
    $EditOtherdetails = $_POST['Otherdetails'];
    $EditAdvpaymentdetails = $_POST['AdvPaymentdetails'];

    $sql = "UPDATE newregistration SET Name = '$EditName',Designation = '$EditDesignation',Section='$EditSection',Establishment='$EditEstablishment',Location='$EditLocation',Bookingdate='$EditBookingdate',Bookingpurpose='$EditBookingpurpose',Contactno='$EditContactno',Authorizedby='$EditAuthorizedby',OtherDetails='$EditOtherdetails',AdvPaymentdetails='$EditAdvpaymentdetails' WHERE TNo = '$EditTNo'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location:booking.php");
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/tempbooking.css">
    <style>
        #editpanel {
            position: fixed;
            z-index: 1000;
            height: 100%;
            width: 100%;
            display: flex;
            justify-content: center;
            /* align-items: center; */
            background-color: #00000079;
        }

        #editpanel .tempbookingpanelform {
            height: 620px;
            width: 1170px;
            background-color: #ccdff4;
            border-radius: 10px;
            /* temp */
            position: relative;
            top: 20px;
            animation: tempbookinginfoform .3s ease;
        }
    </style>
    <title>Temporary Booking</title>
</head>

<body>
    <div id="editpanel">
        <form method="POST" class="tempbookingpanelform">
            <div class="head">
                <h4>Update Temporary Booking Of Selected Location</h4>
                <a href="./booking.php"><i class="fa-solid fa-circle-xmark" onclick="adduserclose()"></i></a>
            </div>
            <div class="middle">
                <div class="tempbookinginfo">
                    <!-- <h4>New Registration</h4> -->
                    <input type="text" name="Name" value="<?php echo $Name ?>">
                    <input type="text" name="Designation" value="<?php echo $Designation ?>">
                    <input type="text" name="Section" value="<?php echo $Section ?>">
                    <input type="text" name="Establishment" value="<?php echo   $Establishment ?>">
                    <input type="text" name="TNo" value="<?php echo $TNo ?>">
                    <input type="text" name="Location" value="<?php echo $Location ?>">

                </div>

                <div class="line"></div>

                <div class="reservationinfo">
                    <div class="date">
                        <span>
                            <input name="Bookingdate" type="date" value="<?php echo $Bookingdate ?>">
                        </span>
                    </div>
                    <input type="text" name="BookingPurpose" value="<?php echo $Bookingpurpose ?>">

                    <input type="text" name="Contactno" value="<?php echo $Contactno ?>">
                    <select name="Authorizedby" class="selectinput">
                        <option value="<?php echo $Authorizedby ?>" selected><?php echo $Authorizedby ?></option>
                        <option value="Self">Self</option>
                        <option value="Other">Other</option>
                    </select>
                    <input type="text" name="Otherdetails" class="my-input" value="<?php echo $Otherdetails ?>">
                    <input type="text" name="AdvPaymentdetails" value="<?php echo $Advpaymentdetails ?>">

                </div>

            </div>
            <div class="footer">
                <button class="btn btn-success" name="tempbookingedit">Edit</button>
            </div>
        </form>
    </div>
</body>

</html>