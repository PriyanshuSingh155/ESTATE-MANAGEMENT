-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2022 at 11:19 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bluebirdhotel`
-- User: `bluebird_user`
-- Password:   `password`
--
DROP DATABASE IF EXISTS bluebirdhotel;
CREATE DATABASE IF NOT EXISTS bluebirdhotel;

DROP USER IF EXISTS'bluebird_user'@'%';
CREATE USER IF NOT EXISTS 'bluebird_user'@'%' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON bluebirdhotel.* TO 'bluebird_user'@'%';
USE bluebirdhotel;



-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(100) NOT NULL,
  `Admin_Email` varchar(50) NOT NULL,
  `Admin_Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_login`
--

INSERT INTO `admin_login` (`admin_id`, `Admin_Email`, `Admin_Password`) VALUES
(1, 'msf@gmail.com', 'msf@1234');


-- --------------------------------------------------------


CREATE TABLE `asset_management` (
  `Estate` varchar(20) NOT NULL,
  `Type` int(2) NOT NULL,
  `Qtrno` varchar(3) NOT NULL,
  `Floor` int(3) NOT NULL,
  `noofroom` int(3) NOT NULL,
  `avlroom` int(3) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



------------------

CREATE TABLE `permanent` (
  `Quarters_No` varchar(50) NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Designation` varchar(60) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `Establishment` varchar(80) NOT NULL,
  `TNo` varchar(80) NOT NULL,/*primary*/
  `Basic` varchar (50) NOT NULL,
  `Categorized_By` varchar(20) NOT NULL,
  `Appointment` date NOT NULL,
  `BirthDate` date NOT NULL,
  `Present_Qtrs` varchar(50) NOT NULL,
  `Choice_Qtrs` varchar(50) NOT NULL,
  `Earlier_changeover` varchar(50) NOT NULL,
  `Surrendered_Qtrs` varchar(50) NOT NULL,
  `Service` varchar(50) NOT NULL,
  `Contact`  varchar(20) NOT NULL
);




..............insertion data.............

INSERT INTO permanent (Quarters_No, Name, Designation, Section, Establishment, TNo, Basic, Categorized_By, Appointment, BirthDate, Present_Qtrs, Choice_Qtrs, Earlier_Changeover, Surrendered_Qtrs, Service, Contact) 
VALUES (41, 'Kajal Thakur', 'CSE', 'CSE2', 'HFHH', 'KHGG', 'GCGG', 'SC', '2022-11-09', '2000-11-09', 'HGH', 'HFHU', 'NOG', 'YFF', 'GYUU', 3542215424);


-----------------------------------------------------------

CREATE TABLE rentcalc(
  TNo varchar(10),
  Lfee float(6),
  Cfee float(6),
  Wfee float(6),
  Efee float(6),
  Mfee float(6),
  Arr float(6),
  Total float(6)
  
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;                                                                                                                                                                               CREATE TABLE dues(


CREATE TABLE dues(
  TNo varchar(10) ,
  Arr float(6)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- AUTO_INCREMENT for table `roombook`
--
ALTER TABLE `roombook`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;






--
-- PRIMARY_KEY for table `deus` AND 'rentcalc'
--
ALTER TABLE dues
  ADD PRIMARY KEY (TNo);


ALTER TABLE rentcalc
  ADD PRIMARY KEY (TNo);


CREATE TABLE newregistration (
  Name varchar(50) NOT NULL,
  Designation varchar(50) NOT NULL,
  Section varchar(50) NOT NULL,
  Establishment varchar(50) NOT NULL,
  PnoTno varchar(50) NOT NULL,
  Location varchar(50) NOT NULL,
  Bookingdate date NOT NULL,
  BookingPurpose varchar(50) NOT NULL,
  Contactno varchar(50) NOT NULL,
  Authorizedby varchar(50) NOT NULL,
  OtherDetails varchar(50) NOT NULL,
  AdvPaymentdetails varchar(50) NOT NULL
) 


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
